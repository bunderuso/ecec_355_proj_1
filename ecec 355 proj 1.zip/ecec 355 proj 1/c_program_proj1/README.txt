This program was created by 
Jakob Casamassima
Benedict Hoffmockel
Aaron Plaksen

To call the function please go to /c_program_proj1/DREXEL-DISCO-RISC-V-Simulator-C-Impl-main/project_1. In this directory the program can be compiled with "make" and will be given the name RVSim

Once the program is compiled please use ./RVSim ../cpu_traces/project_one for the test file. Please note any directory or file can be used as long as it contains the following valid instructions:
add
slli
ld
bne
addi

Attempting to give any instructions outside of this will cause the program to terminate with the wrong results. 